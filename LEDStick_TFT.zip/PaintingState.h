#ifndef _PAINTINGSTATE_h
#define _PAINTINGSTATE_h

enum PaintingState {
	Waiting = 1,
	Painting = 2,
	StoppedPainting = 3,
	Exit = 4
};


#endif

